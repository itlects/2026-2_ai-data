# Teachable Machine 의류 이미지 실습 패키지

이 자료는 교육용으로 생성한 **의류 그림(합성 일러스트)**이며 실제 제품 사진이 아닙니다. `train` 폴더에 티셔츠·바지·운동화 각 24장, `test` 폴더에 각 10장이 포함되어 있습니다.

1. https://teachablemachine.withgoogle.com 에서 Image Project → Standard Image Model 선택
2. T-shirt / Pants / Sneakers의 3개 클래스를 만들고 `train/tshirt`, `train/pants`, `train/sneakers` 폴더 이미지(각 24장)만 추가
3. Train Model 후 Preview의 Webcam으로 **새로운 실제 옷**을 비춰 실시간 분류
4. Preview의 File/Upload로 **`test` 폴더**의 이미지 30장(각 10장)을 하나씩 선택해 평가
5. 실제 의류는 직접 촬영 후 별도 학습하는 것이 권장됨. 합성 그림 기반 모델이 실제 의류 사진에서도 잘 동작한다고 보장할 수 없습니다.
6. `test` 이미지를 학습에 넣지 마세요. 데이터 혼합을 방지하세요.
